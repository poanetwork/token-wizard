# web3

This is a main package of [web3.js][repo]

Please read the [documentation][docs] for more.

## Installation

### Node.js

```bash
npm install web3
```
